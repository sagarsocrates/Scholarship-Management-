-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2018 at 07:43 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ADD_SCH` (IN `usn` VARCHAR(20), IN `nam` VARCHAR(20), IN `schname` VARCHAR(20))  BEGIN
insert into myscholarships (usn,Name,Schname) values (usn,nam,schname);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(50) NOT NULL,
  `adminname` varchar(20) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `adminname`, `pass`) VALUES
(123, 'Krithika', '2229');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `appid` int(11) NOT NULL,
  `usn` varchar(50) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `Income` bigint(50) NOT NULL,
  `STATE` varchar(50) NOT NULL,
  `CASTE` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `PHONE` bigint(20) NOT NULL,
  `MARKS` int(20) NOT NULL,
  `COLLEGE` varchar(50) NOT NULL,
  `SCHNO` int(50) NOT NULL,
  `SCHNAME` varchar(200) NOT NULL,
  `DOA` date NOT NULL,
  `course` varchar(50) NOT NULL,
  `Sem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`appid`, `usn`, `NAME`, `Income`, `STATE`, `CASTE`, `EMAIL`, `PHONE`, `MARKS`, `COLLEGE`, `SCHNO`, `SCHNAME`, `DOA`, `course`, `Sem`) VALUES
(2, '129', 'Sagar', 9000, 'karnataka', 'SC', 'sagar@gmail.com', 9087654321, 90, 'hkbk', 3, 'Disability', '2018-11-24', 'BTECH', 1);

--
-- Triggers `application`
--
DELIMITER $$
CREATE TRIGGER `sanctioned_trig` AFTER INSERT ON `application` FOR EACH ROW INSERT INTO sanction  (marks,caste,adminid,appid,Name,Scholarship,Schno,sem,Income) VALUES
(NEW.MARKS,NEW.CASTE,'123',NEW.appid,NEW.NAME,NEW.SCHNAME,NEW.SCHNO,NEW.Sem,NEW.Income)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `myscholarships`
--

CREATE TABLE `myscholarships` (
  `usn` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Schname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `noofsanctions`
--

CREATE TABLE `noofsanctions` (
  `Schno` int(11) NOT NULL,
  `sanid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sanction`
--

CREATE TABLE `sanction` (
  `sanid` int(10) NOT NULL,
  `marks` int(10) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `adminid` int(10) NOT NULL,
  `appid` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Scholarship` varchar(50) NOT NULL,
  `Schno` int(11) NOT NULL,
  `sem` int(11) NOT NULL,
  `Income` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `sanction`
--
DELIMITER $$
CREATE TRIGGER `aftersan` AFTER INSERT ON `sanction` FOR EACH ROW insert into noofsanctions VALUES(NEW.schno,NEW.sanid)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `scholarship`
--

CREATE TABLE `scholarship` (
  `schno` int(30) NOT NULL,
  `schname` varchar(100) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `caste` varchar(15) NOT NULL,
  `marks` int(10) NOT NULL,
  `fathersincome` int(50) NOT NULL,
  `open` date NOT NULL,
  `close` date NOT NULL,
  `adminid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scholarship`
--

INSERT INTO `scholarship` (`schno`, `schname`, `religion`, `caste`, `marks`, `fathersincome`, `open`, `close`, `adminid`) VALUES
(1, 'Post Matric ', 'Hindu', 'obc', 60, 200000, '2018-10-15', '2018-11-24', 123),
(2, 'Merit Cum Means', 'muslim', 'obc', 50, 250000, '2018-10-15', '2018-11-25', 123),
(3, 'Disability', 'hindu', 'sc', 55, 600000, '2018-10-15', '2018-11-29', 123),
(4, 'Prime Ministers ', 'hindu', 'general', 60, 500000, '2018-10-15', '2018-11-26', 123),
(5, 'Central Scheme ', 'christian/hindu', 'general', 80, 600000, '2018-10-15', '2018-11-24', 123),
(6, 'ONGC ', 'christian/hindu', 'st', 60, 450000, '2018-10-15', '2018-11-27', 123),
(7, 'S N Bose ', 'christian/hindu', 'obc', 80, 300000, '2018-10-15', '2018-11-25', 123),
(8, 'AICTE ', 'christian/muslim', 'general', 65, 600000, '2018-10-15', '2018-11-26', 123),
(9, 'Khoraona Program ', 'christian/hindu', 'general', 80, 400000, '2018-10-15', '2018-11-30', 123),
(10, ' Ramanunjan ', 'christian/hindu', 'obc', 90, 500000, '2018-10-15', '2018-11-20', 123);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(200) NOT NULL,
  `usn` varchar(500) NOT NULL,
  `college` varchar(200) NOT NULL,
  `semes` int(5) NOT NULL,
  `email` varchar(30) NOT NULL,
  `percentage` int(3) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `caste` varchar(15) NOT NULL,
  `Income` int(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmm` varchar(50) NOT NULL,
  `ACTIVITY` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `usn`, `college`, `semes`, `email`, `percentage`, `religion`, `caste`, `Income`, `password`, `confirmm`, `ACTIVITY`) VALUES
('Krithika', '068', 'hkbk', 1, 'krithika@gmail.com', 90, 'HINDU', 'SC', 40000, '0068', '0068', '1'),
('shalini', '069', 'hkbk', 5, 'shalini@gmail.com', 86, 'HINDU', 'OBC', 50000, '0069', '0069', '1'),
('madhu', '071', 'hkbk', 5, 'madhu@gmail.com', 88, 'HINDU', 'SC', 55000, '0071', '0071', '0'),
('Sagar', '129', 'hkbk', 1, 'sagar@gmail', 90, 'HINDU', 'SC', 9000, '0129', '0129', '1'),
('shivu', '146', 'hkbk', 5, 'shivu@gmail.com', 90, 'HINDU', 'SC', 78888, '0146', '0146', '1'),
('Usama Masood II', '1hk16cs097', 'HKBKCE', 6, 'musama646@gmail.com', 81, 'MUSLIM', 'obc', 90000, 'usamausama', 'usamausama', '1'),
('shravani', '1hk16cs148', 'hkbk', 6, 'shravanigmail.com', 65, 'HINDU', 'SC', 65000, 'madhu', 'madhu', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`appid`),
  ADD UNIQUE KEY `nosame` (`usn`,`SCHNO`,`Sem`) USING BTREE;

--
-- Indexes for table `sanction`
--
ALTER TABLE `sanction`
  ADD PRIMARY KEY (`sanid`);

--
-- Indexes for table `scholarship`
--
ALTER TABLE `scholarship`
  ADD PRIMARY KEY (`schno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `appid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sanction`
--
ALTER TABLE `sanction`
  MODIFY `sanid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
