Step1-Install xammp-win32-5.6.31-0-VC11-installer
Step2-Open XAMMP Control Panel
Step3-Start Apache and MySQL
Step4-Copy and Paste the "Pro folder" in the installation path-C:\xampp\htdocs
Step5-Launch any browser and search for http://localhost/phpmyadmin/ 
Step6-Create a New Database named "proj"(left side of the browser)
Step7-Click on the newly created "test" Database
Step8-Click on import, choose file "test.sql" from the folder and scroll down click GO
Step9-Add a new tab and search for http://localhost/Pro
 Login and Execute.